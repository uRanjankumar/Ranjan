﻿/// <reference path="angular.min.js" />

var myApp = angular.module("myModule", [])
                    .controller("myController", function ($scope) {
                        var scoreBoard = {
                            Score: 0,
                            Wickets: 0,
                            Overs: 0,
                            Balls: 0
                        };

                        $scope.ScoreCalc = function (type) {
                            switch (type) {
                                case 'Wide':
                                    scoreBoard.Score++;
                                    break;
                                case 'NoBall':
                                    scoreBoard.Score++;
                                    break;
                                case '1':
                                    scoreBoard.Score++;
                                    scoreBoard.Balls++;
                                    break;
                                case '2':
                                    scoreBoard.Score = scoreBoard.Score + 2;
                                    scoreBoard.Balls++;
                                    break;
                                case '3':
                                    scoreBoard.Score = scoreBoard.Score + 3;
                                    scoreBoard.Balls++;
                                    break;
                                case '4':
                                    scoreBoard.Score = scoreBoard.Score + 4;
                                    scoreBoard.Balls++;
                                    break;
                                case '6':
                                    scoreBoard.Score = scoreBoard.Score + 6;
                                    scoreBoard.Balls++;
                                    break;
                                case 'Dot':
                                    scoreBoard.Balls++;
                                    break;
                                case 'Wicket':
                                    scoreBoard.Balls++;
                                    scoreBoard.Wickets++;
                                    break;
                                default:

                            }

                            if(scoreBoard.Balls == 6)
                            {
                                scoreBoard.Balls = 0;
                                scoreBoard.Overs++;
                            }

                        };
                        $scope.ScoreBoard = scoreBoard;

                    });